#!/usr/bin/env python3
"""
auto_localization_node.py — ROS Noetic
Auto-localización sin pose inicial hardcodeada.

Estrategia:
  1. Llama a /global_localization → esparce partículas por todo el mapa
  2. Gira sobre sí mismo para que el LIDAR vea el entorno
  3. Monitoriza /particlecloud para detectar cuándo convergen las partículas
  4. Publica en /localization_ready cuando la localización es fiable

Dependencias:
    rospy, std_srvs, geometry_msgs, nav_msgs

Uso:
    rosrun <tu_paquete> auto_localization_node.py

Lanzar ANTES de este nodo:
    - roscore
    - turtlebot3_robot.launch  (en el robot)
    - turtlebot3_navigation.launch map_file:=... (en el PC)
"""

import rospy
import math
import numpy as np
from std_srvs.srv import Empty
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Odometry

# ─── PARÁMETROS ───────────────────────────────────────────────────────────────

# Velocidad angular del giro de exploración (rad/s)
# 0.5 es lento y seguro; súbelo a 0.8 si el mapa es complejo y tarda mucho
ANGULAR_SPEED = 0.5

# Máximo de vueltas completas antes de rendirse y avisar
MAX_ROTATIONS = 3

# Umbral de convergencia: desviación estándar máxima aceptable de las
# partículas en X e Y (metros). Cuando las partículas están más juntas
# que esto, consideramos que el robot sabe dónde está.
# Ajusta según el tamaño de tu mapa:
#   mapa pequeño (<5x5m): 0.15 - 0.20
#   mapa mediano (laboratorio): 0.25 - 0.35
#   mapa grande: 0.40 - 0.50
CONVERGENCE_THRESHOLD_XY = 0.30   # metros
CONVERGENCE_THRESHOLD_YAW = 0.20  # radianes

# Número mínimo de partículas para considerar válida la nube
# (AMCL adapta el número; si hay muy pocas, aún está inicializando)
MIN_PARTICLES = 50

# Topic donde publicamos que la localización está lista
READY_TOPIC = "/localization_ready"

# ──────────────────────────────────────────────────────────────────────────────


class AutoLocalizationNode:

    def __init__(self):
        rospy.init_node("auto_localization_node", anonymous=False)
        rospy.loginfo("=== Auto-localización iniciada ===")

        self.localized     = False
        self.particle_std  = float("inf")  # dispersión actual de partículas
        self.particle_yaw_std = float("inf")

        # Publisher para mover el robot
        self.cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

        # Publisher para avisar al resto del sistema
        self.ready_pub = rospy.Publisher(READY_TOPIC, Bool,
                                         queue_size=1, latch=True)

        # Suscripción a la nube de partículas de AMCL
        # PoseArray: cada pose es una hipótesis de dónde está el robot
        from geometry_msgs.msg import PoseArray
        rospy.Subscriber("/particlecloud", PoseArray, self.particle_callback)

        # Espera a que AMCL esté listo
        rospy.loginfo("Esperando servicio /global_localization...")
        rospy.wait_for_service("/global_localization", timeout=30.0)
        rospy.loginfo("AMCL listo.")

        # Ejecuta la secuencia de auto-localización
        self.run()

    # ── Callback ──────────────────────────────────────────────────────────────

    def particle_callback(self, msg):
        """
        Analiza la dispersión de la nube de partículas.
        Cuando todas las partículas están juntas = robot localizado.
        """
        if len(msg.poses) < MIN_PARTICLES:
            return

        # Extrae posiciones XY de todas las partículas
        xs = np.array([p.position.x for p in msg.poses])
        ys = np.array([p.position.y for p in msg.poses])

        # Extrae yaw de cada partícula (de quaternion)
        yaws = []
        for p in msg.poses:
            q = p.orientation
            yaw = math.atan2(2*(q.w*q.z + q.x*q.y),
                             1 - 2*(q.y*q.y + q.z*q.z))
            yaws.append(yaw)
        yaws = np.array(yaws)

        # Desviación estándar: cuanto menor, más concentradas están
        self.particle_std     = max(np.std(xs), np.std(ys))
        self.particle_yaw_std = np.std(yaws)

        if (self.particle_std     < CONVERGENCE_THRESHOLD_XY and
                self.particle_yaw_std < CONVERGENCE_THRESHOLD_YAW):
            self.localized = True

    # ── Lógica principal ──────────────────────────────────────────────────────

    def run(self):
        # 1. Dispersa partículas por todo el mapa
        self.global_localization()

        # 2. Gira y espera convergencia
        self.spin_until_localized()

        # 3. Para el robot
        self.stop()

        if self.localized:
            rospy.loginfo("Robot localizado correctamente.")
            self.ready_pub.publish(Bool(data=True))
        else:
            rospy.logwarn(
                f"No se convergió tras {MAX_ROTATIONS} vueltas. "
                f"Dispersión actual: XY={self.particle_std:.3f}m "
                f"Yaw={self.particle_yaw_std:.3f}rad. "
                "Publicando igualmente para no bloquear el sistema."
            )
            self.ready_pub.publish(Bool(data=False))

    def global_localization(self):
        """Llama al servicio de AMCL que esparce partículas por todo el mapa."""
        try:
            srv = rospy.ServiceProxy("/global_localization", Empty)
            srv()
            rospy.loginfo("Partículas dispersadas por el mapa.")
            rospy.sleep(1.0)  # pequeña pausa para que AMCL procese
        except rospy.ServiceException as e:
            rospy.logerr(f"Error llamando a /global_localization: {e}")

    def spin_until_localized(self):
        """
        Gira sobre sí mismo hasta que las partículas converjan o
        se alcance el máximo de rotaciones.
        """
        rate = rospy.Rate(10)  # 10 Hz

        # Calcular cuántos ciclos son una vuelta completa (360°)
        # Una vuelta = 2π radianes / velocidad angular
        seconds_per_rotation = (2 * math.pi) / ANGULAR_SPEED
        cycles_per_rotation  = int(seconds_per_rotation * 10)  # a 10 Hz
        total_cycles         = cycles_per_rotation * MAX_ROTATIONS

        twist = Twist()
        twist.angular.z = ANGULAR_SPEED

        rospy.loginfo(
            f"Girando a {ANGULAR_SPEED} rad/s. "
            f"Máx. {MAX_ROTATIONS} vueltas ({total_cycles} ciclos)..."
        )

        for i in range(total_cycles):
            if rospy.is_shutdown():
                break

            if self.localized:
                rotations_done = i / cycles_per_rotation
                rospy.loginfo(
                    f"Convergencia alcanzada tras {rotations_done:.1f} vueltas. "
                    f"Dispersion XY={self.particle_std:.3f}m "
                    f"Yaw={self.particle_yaw_std:.3f}rad"
                )
                break

            # Log de progreso cada vuelta completa
            if i > 0 and i % cycles_per_rotation == 0:
                vuelta = i // cycles_per_rotation
                rospy.loginfo(
                    f"Vuelta {vuelta}/{MAX_ROTATIONS} — "
                    f"Dispersion XY={self.particle_std:.3f}m "
                    f"(umbral={CONVERGENCE_THRESHOLD_XY}m)"
                )

            self.cmd_pub.publish(twist)
            rate.sleep()

    def stop(self):
        """Para el robot completamente."""
        self.cmd_pub.publish(Twist())
        rospy.sleep(0.5)


if __name__ == "__main__":
    try:
        AutoLocalizationNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
