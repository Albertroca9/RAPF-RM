#!/usr/bin/env python3

import sys
import rospy
import actionlib

from control_msgs.msg import FollowJointTrajectoryAction
from control_msgs.msg import FollowJointTrajectoryGoal
from trajectory_msgs.msg import JointTrajectoryPoint


class GripperCommander:
    def __init__(self):
        rospy.init_node("waffle_gripper_commander")

        self.action_name = rospy.get_param(
            "~action_name",
            "/gripper_controller/follow_joint_trajectory"
        )

        self.joint_name = rospy.get_param("~joint_name", "gripper")

        self.open_position = rospy.get_param("~open_position", 0.010)
        self.close_position = rospy.get_param("~close_position", -0.010)
        self.duration = rospy.get_param("~duration", 1.0)

        rospy.loginfo("Action server usado: %s", self.action_name)
        rospy.loginfo("Joint de pinza usado: %s", self.joint_name)

        self.client = actionlib.SimpleActionClient(
            self.action_name,
            FollowJointTrajectoryAction
        )

        rospy.loginfo("Esperando al controlador de la pinza...")

        if not self.client.wait_for_server(rospy.Duration(5.0)):
            rospy.logerr("No se ha encontrado el action server de la pinza.")
            rospy.logerr("Comprueba con:")
            rospy.logerr("  rostopic list | grep gripper")
            rospy.signal_shutdown("Action server no encontrado")
            return

        rospy.loginfo("Controlador de pinza encontrado.")

    def send_position(self, position):
        goal = FollowJointTrajectoryGoal()

        goal.trajectory.header.stamp = rospy.Time.now()
        goal.trajectory.joint_names = [self.joint_name]

        point = JointTrajectoryPoint()
        point.positions = [position]
        point.velocities = [0.0]
        point.time_from_start = rospy.Duration(self.duration)

        goal.trajectory.points = [point]

        rospy.loginfo("Enviando posición %.4f a la pinza...", position)

        self.client.send_goal(goal)

        finished = self.client.wait_for_result(
            rospy.Duration(self.duration + 2.0)
        )

        if finished:
            rospy.loginfo("Movimiento terminado.")
        else:
            rospy.logwarn("El movimiento no terminó dentro del tiempo esperado.")

    def open(self):
        self.send_position(self.open_position)

    def close(self):
        self.send_position(self.close_position)


def main():
    if len(sys.argv) < 2:
        print("Uso:")
        print("  rosrun waffle_gripper_control gripper_cmd.py open")
        print("  rosrun waffle_gripper_control gripper_cmd.py close")
        print("  rosrun waffle_gripper_control gripper_cmd.py pos 0.005")
        return

    commander = GripperCommander()

    command = sys.argv[1].lower()

    if command == "open":
        commander.open()

    elif command == "close":
        commander.close()

    elif command == "pos":
        if len(sys.argv) < 3:
            rospy.logerr("Falta la posición. Ejemplo:")
            rospy.logerr("  rosrun waffle_gripper_control gripper_cmd.py pos 0.005")
            return

        position = float(sys.argv[2])
        commander.send_position(position)

    else:
        rospy.logerr("Comando no reconocido. Usa open, close o pos.")


if __name__ == "__main__":
    main()
