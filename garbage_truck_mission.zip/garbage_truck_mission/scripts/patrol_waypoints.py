#!/usr/bin/env python3

import rospy
import actionlib

from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus
from std_srvs.srv import Empty


class PatrolWaypoints:
    def __init__(self):
        rospy.init_node("patrol_waypoints_node")

        self.client = actionlib.SimpleActionClient("move_base", MoveBaseAction)

        rospy.loginfo("Esperando a move_base...")
        self.client.wait_for_server()
        rospy.loginfo("move_base disponible.")

        rospy.loginfo("Esperando servicio /move_base/clear_costmaps...")
        rospy.wait_for_service("/move_base/clear_costmaps")
        self.clear_costmaps_srv = rospy.ServiceProxy(
            "/move_base/clear_costmaps",
            Empty
        )

        # Waypoints reales de patrulla guardados desde /amcl_pose/pose/pose.
        #
        # x, y = position.x, position.y
        # z, w = orientation.z, orientation.w
        #
        # Son puntos seguros del mapa, no puntos de basura ni contenedores.
        self.waypoints = {
            "patrulla_1": {
                "x": 1.5027661285869702,
                "y": -0.20457379484675126,
                "z": -0.049627939375435526,
                "w": 0.9987677746269891,
            },
            "patrulla_2": {
                "x": 1.0230466484816345,
                "y": -1.1791468486139556,
                "z": 0.9658667337589208,
                "w": 0.2590394808091496,
            },
            "patrulla_3": {
                "x": 0.2229378007997077,
                "y": -1.8175898882828854,
                "z": -0.649189045086226,
                "w": 0.7606270990045214,
            },
            "patrulla_4": {
                "x": 0.3060672159983449,
                "y": -0.5017486663198123,
                "z": 0.27397595715513,
                "w": 0.9617365413152036,
            },
        }

        self.route = [
            "patrulla_1",
            "patrulla_2",
            "patrulla_4",
            "patrulla_3",
        ]

        self.wait_time_at_waypoint = 2.0

    def clear_costmaps(self):
        try:
            rospy.loginfo("Limpiando costmaps...")
            self.clear_costmaps_srv()
            rospy.sleep(0.5)
        except rospy.ServiceException as e:
            rospy.logwarn("No se pudieron limpiar costmaps: %s", e)

    def build_goal(self, waypoint_name):
        wp = self.waypoints[waypoint_name]

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        goal.target_pose.pose.position.x = wp["x"]
        goal.target_pose.pose.position.y = wp["y"]
        goal.target_pose.pose.position.z = 0.0

        goal.target_pose.pose.orientation.x = 0.0
        goal.target_pose.pose.orientation.y = 0.0
        goal.target_pose.pose.orientation.z = wp["z"]
        goal.target_pose.pose.orientation.w = wp["w"]

        return goal

    def go_to_waypoint(self, waypoint_name, retry=True):
        if waypoint_name not in self.waypoints:
            rospy.logerr("Waypoint no existe: %s", waypoint_name)
            return False

        goal = self.build_goal(waypoint_name)
        wp = self.waypoints[waypoint_name]

        rospy.loginfo(
            "Yendo a %s -> x=%.3f, y=%.3f, z=%.3f, w=%.3f",
            waypoint_name,
            wp["x"],
            wp["y"],
            wp["z"],
            wp["w"],
        )

        self.client.send_goal(goal)
        self.client.wait_for_result()

        state = self.client.get_state()

        if state == GoalStatus.SUCCEEDED:
            rospy.loginfo("Llegada correcta a %s", waypoint_name)
            rospy.sleep(self.wait_time_at_waypoint)
            return True

        rospy.logwarn(
            "Fallo al llegar a %s. Estado move_base: %s",
            waypoint_name,
            state,
        )

        if retry:
            rospy.logwarn(
                "Reintentando %s tras limpiar costmaps...",
                waypoint_name
            )
            self.clear_costmaps()
            return self.go_to_waypoint(waypoint_name, retry=False)

        return False

    def run_patrol_once(self):
        rospy.loginfo("Iniciando patrulla una vez...")

        for waypoint in self.route:
            if rospy.is_shutdown():
                break

            ok = self.go_to_waypoint(waypoint)

            if not ok:
                rospy.logwarn(
                    "No se pudo completar el waypoint: %s",
                    waypoint
                )
                return False

        rospy.loginfo("Patrulla completada.")
        return True

    def run_patrol_loop(self):
        rospy.loginfo("Iniciando patrulla en bucle...")

        while not rospy.is_shutdown():
            self.run_patrol_once()


if __name__ == "__main__":
    patrol = PatrolWaypoints()

    # De momento hace una sola vuelta:
    patrol.run_patrol_once()

    # Cuando una vuelta funcione bien, cambia la línea anterior por:
    # patrol.run_patrol_loop()
