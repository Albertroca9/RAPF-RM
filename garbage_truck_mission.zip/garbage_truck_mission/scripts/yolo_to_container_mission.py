#!/usr/bin/env python3

import subprocess
import rospy

from std_msgs.msg import String
from actionlib_msgs.msg import GoalID


class YoloToContainerMission:
    def __init__(self):
        rospy.init_node("yolo_to_container_mission_node")

        self.busy = False

        self.container_to_roadmap_target = {
            "plastic": "plastico",
            "paper": "papel",
            "glass": "vidre",

            # Si tenéis contenedor orgánico, mandamos residual a orgánico.
            # Si tenéis un contenedor específico de rechazo/residual,
            # cambia "organico" por el nombre que tengas en roadmap_navigator.py.
            "residual": "organico",
            "organic": "organico",
            "organico": "organico",
        }

        self.cancel_pub = rospy.Publisher(
            "/move_base/cancel",
            GoalID,
            queue_size=1
        )

        rospy.Subscriber(
            "/detected_container",
            String,
            self.detected_container_callback,
            queue_size=1
        )

        rospy.loginfo("YOLO to container mission node started")
        rospy.loginfo("Listening to /detected_container")

    def detected_container_callback(self, msg):
        detected_container = msg.data.strip().lower()

        if self.busy:
            rospy.logwarn(
                "Mission busy. Ignoring detection: %s",
                detected_container
            )
            return

        if detected_container not in self.container_to_roadmap_target:
            rospy.logwarn(
                "Unknown detected container: %s",
                detected_container
            )
            return

        roadmap_target = self.container_to_roadmap_target[detected_container]

        rospy.logwarn(
            "Detection received: %s -> going to %s",
            detected_container,
            roadmap_target
        )

        self.go_to_container(roadmap_target)

    def cancel_navigation(self):
        rospy.loginfo("Cancelling current move_base goal...")
        self.cancel_pub.publish(GoalID())
        rospy.sleep(0.5)

    def clear_costmaps(self):
        rospy.loginfo("Clearing costmaps...")
        try:
            subprocess.call([
                "rosservice",
                "call",
                "/move_base/clear_costmaps",
                "{}"
            ])
        except Exception as e:
            rospy.logwarn("Could not clear costmaps: %s", e)

    def go_to_container(self, roadmap_target):
        self.busy = True

        try:
            self.cancel_navigation()
            self.clear_costmaps()

            command = [
                "rosrun",
                "garbage_truck_mission",
                "roadmap_navigator.py",
                "go",
                roadmap_target
            ]

            rospy.loginfo("Executing command: %s", " ".join(command))

            result = subprocess.call(command)

            if result == 0:
                rospy.loginfo("Finished navigation to %s", roadmap_target)
            else:
                rospy.logwarn(
                    "Navigation command finished with code: %s",
                    result
                )

        finally:
            self.busy = False


if __name__ == "__main__":
    try:
        node = YoloToContainerMission()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
