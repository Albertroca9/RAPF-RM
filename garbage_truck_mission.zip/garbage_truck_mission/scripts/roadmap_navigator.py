#!/usr/bin/env python3

import sys
import math
import heapq
import rospy
import actionlib

from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus
from std_srvs.srv import Empty
from geometry_msgs.msg import PoseWithCovarianceStamped


class RoadmapNavigator:
    def __init__(self):
        rospy.init_node("roadmap_navigator_node")

        self.current_pose = None

        rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.amcl_callback)

        self.client = actionlib.SimpleActionClient("move_base", MoveBaseAction)

        rospy.loginfo("Esperando a move_base...")
        self.client.wait_for_server()
        rospy.loginfo("move_base disponible.")

        rospy.loginfo("Esperando servicio /move_base/clear_costmaps...")
        rospy.wait_for_service("/move_base/clear_costmaps")
        self.clear_costmaps_srv = rospy.ServiceProxy(
            "/move_base/clear_costmaps",
            Empty
        )

        # ==========================================================
        # NODOS DEL ROADMAP
        # ==========================================================
        #
        # Estos puntos son nodos seguros del mapa.
        # x, y = position.x, position.y
        # z, w = orientation.z, orientation.w
        #
        # IMPORTANTE:
        # Para contenedores, usa puntos de "approach", no puntos pegados
        # al contenedor. Deben estar en zona libre y navegable.

        self.nodes = {
            # -----------------------
            # PUNTOS DE PATRULLA
            # -----------------------
            "patrulla_1": {
                "x": 1.5027661285869702,
                "y": -0.20457379484675126,
                "z": -0.049627939375435526,
                "w": 0.9987677746269891,
            },
            "patrulla_2": {
                "x": 1.0230466484816345,
                "y": -1.1791468486139556,
                "z": 0.9658667337589208,
                "w": 0.2590394808091496,
            },
            "patrulla_3": {
                "x": 0.2229378007997077,
                "y": -1.8175898882828854,
                "z": -0.649189045086226,
                "w": 0.7606270990045214,
            },
            "patrulla_4": {
                "x": 0.3060672159983449,
                "y": -0.5017486663198123,
                "z": 0.27397595715513,
                "w": 0.9617365413152036,
            },

            # -----------------------
            # CONTENEDORES / APPROACH
            # -----------------------
            # CAMBIA ESTOS PUNTOS SI HAS REHECHO LOS WAYPOINTS.
            # Deben ser puntos seguros delante del contenedor, no pegados.

            "contenedor_vidre": {
                "x": 1.5457476735805733,
                "y": -1.6645684387612363,
                "z": 0.004990458565167522,
                "w": 0.9999875475841233,
            },
            "contenedor_plastico": {
                "x": 0.10400237847006158,
                "y": -0.01979264610213303,
                "z": 0.7170454867738468,
                "w": 0.6970263767586252,
            },
            "contenedor_organico": {
                "x": 0.8742845577500119,
                "y": -1.0830120835967374,
                "z": 0.9712895800886936,
                "w": 0.23790029762723972,
            },
            "contenedor_paper_carto": {
                "x": 0.058417248463857555,
                "y": -0.035557259670048774,
                "z": 0.004990458565167522,
                "w": 0.9999875475841233,
            },
        }

        # ==========================================================
        # GRAFO DEL ROADMAP
        # ==========================================================
        #
        # Aquí defines qué nodos están conectados de forma segura.
        # No pongas conexiones que obliguen al robot a pasar pegado a paredes.
        #
        # Si una conexión falla en la práctica, elimínala o mete un nodo
        # intermedio más seguro.

        self.graph = {
            "patrulla_1": [
                "patrulla_2",
                "patrulla_4",
            ],

            "patrulla_2": [
                "patrulla_1",
                "patrulla_3",
                "contenedor_organico",
                "contenedor_vidre",
            ],

            "patrulla_3": [
                "patrulla_2",
                "patrulla_4",
                "contenedor_vidre",
                "contenedor_organico",
            ],

            "patrulla_4": [
                "patrulla_1",
                "patrulla_3",
                "contenedor_plastico",
                "contenedor_paper_carto",
            ],

            "contenedor_vidre": [
                "patrulla_2",
                "patrulla_3",
            ],

            "contenedor_plastico": [
                "patrulla_4",
            ],

            "contenedor_organico": [
                "patrulla_2",
                "patrulla_3",
            ],

            "contenedor_paper_carto": [
                "patrulla_4",
            ],
        }

        self.container_aliases = {
            "vidre": "contenedor_vidre",
            "vidrio": "contenedor_vidre",
            "glass": "contenedor_vidre",

            "plastico": "contenedor_plastico",
            "plastic": "contenedor_plastico",

            "organico": "contenedor_organico",
            "organic": "contenedor_organico",

            "paper": "contenedor_paper_carto",
            "papel": "contenedor_paper_carto",
            "carto": "contenedor_paper_carto",
            "carton": "contenedor_paper_carto",
            "paper_carto": "contenedor_paper_carto",
        }

        self.patrol_route = [
            "patrulla_1",
            "patrulla_2",
            "patrulla_3",
            "patrulla_4",
        ]

        self.wait_time_at_node = 2.0

    # ==========================================================
    # CALLBACKS
    # ==========================================================

    def amcl_callback(self, msg):
        self.current_pose = msg.pose.pose

    # ==========================================================
    # UTILIDADES
    # ==========================================================

    def clear_costmaps(self):
        try:
            rospy.loginfo("Limpiando costmaps...")
            self.clear_costmaps_srv()
            rospy.sleep(0.5)
        except rospy.ServiceException as e:
            rospy.logwarn("No se pudieron limpiar costmaps: %s", e)

    def distance_between_nodes(self, a, b):
        na = self.nodes[a]
        nb = self.nodes[b]

        dx = na["x"] - nb["x"]
        dy = na["y"] - nb["y"]

        return math.sqrt(dx * dx + dy * dy)

    def distance_pose_to_node(self, pose, node_name):
        node = self.nodes[node_name]

        dx = pose.position.x - node["x"]
        dy = pose.position.y - node["y"]

        return math.sqrt(dx * dx + dy * dy)

    def get_nearest_node(self):
        rospy.loginfo("Esperando /amcl_pose para saber posición actual...")

        timeout = rospy.Time.now() + rospy.Duration(5.0)

        while self.current_pose is None and not rospy.is_shutdown():
            if rospy.Time.now() > timeout:
                rospy.logwarn("No se recibió /amcl_pose a tiempo.")
                return None
            rospy.sleep(0.1)

        nearest = None
        best_dist = float("inf")

        for node_name in self.nodes:
            d = self.distance_pose_to_node(self.current_pose, node_name)

            if d < best_dist:
                best_dist = d
                nearest = node_name

        rospy.loginfo(
            "Nodo más cercano actual: %s (distancia %.3f m)",
            nearest,
            best_dist
        )

        return nearest

    def normalize_target(self, target):
        target = target.strip().lower()
        return self.container_aliases.get(target, target)

    # ==========================================================
    # PLANIFICACIÓN SOBRE ROADMAP
    # ==========================================================

    def shortest_path(self, start, goal):
        if start not in self.nodes:
            rospy.logerr("Nodo inicial no existe: %s", start)
            return None

        if goal not in self.nodes:
            rospy.logerr("Nodo objetivo no existe: %s", goal)
            return None

        queue = []
        heapq.heappush(queue, (0.0, start, [start]))

        visited = set()

        while queue:
            cost, node, path = heapq.heappop(queue)

            if node == goal:
                return path

            if node in visited:
                continue

            visited.add(node)

            for neighbor in self.graph.get(node, []):
                if neighbor in visited:
                    continue

                edge_cost = self.distance_between_nodes(node, neighbor)
                new_cost = cost + edge_cost
                new_path = path + [neighbor]

                heapq.heappush(queue, (new_cost, neighbor, new_path))

        rospy.logwarn("No se encontró ruta de %s a %s", start, goal)
        return None

    # ==========================================================
    # MOVIMIENTO CON MOVE_BASE
    # ==========================================================

    def build_goal(self, node_name):
        node = self.nodes[node_name]

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        goal.target_pose.pose.position.x = node["x"]
        goal.target_pose.pose.position.y = node["y"]
        goal.target_pose.pose.position.z = 0.0

        goal.target_pose.pose.orientation.x = 0.0
        goal.target_pose.pose.orientation.y = 0.0
        goal.target_pose.pose.orientation.z = node["z"]
        goal.target_pose.pose.orientation.w = node["w"]

        return goal

    def go_to_node(self, node_name, retry=True):
        if node_name not in self.nodes:
            rospy.logerr("Nodo no existe: %s", node_name)
            return False

        node = self.nodes[node_name]

        rospy.loginfo(
            "Yendo a %s -> x=%.3f, y=%.3f, z=%.3f, w=%.3f",
            node_name,
            node["x"],
            node["y"],
            node["z"],
            node["w"],
        )

        goal = self.build_goal(node_name)

        self.client.send_goal(goal)
        self.client.wait_for_result()

        state = self.client.get_state()

        if state == GoalStatus.SUCCEEDED:
            rospy.loginfo("Llegada correcta a %s", node_name)
            rospy.sleep(self.wait_time_at_node)
            return True

        rospy.logwarn(
            "Fallo al llegar a %s. Estado move_base: %s",
            node_name,
            state
        )

        if retry:
            rospy.logwarn("Reintentando %s tras limpiar costmaps...", node_name)
            self.clear_costmaps()
            return self.go_to_node(node_name, retry=False)

        return False

    def follow_path(self, path):
        if not path:
            rospy.logwarn("Ruta vacía.")
            return False

        rospy.loginfo("Ejecutando ruta: %s", " -> ".join(path))

        # Si el primer nodo es el nodo más cercano actual, lo saltamos.
        # No hace falta navegar hacia donde ya estamos aproximadamente.
        execution_path = path[1:] if len(path) > 1 else path

        for node in execution_path:
            if rospy.is_shutdown():
                return False

            ok = self.go_to_node(node)

            if not ok:
                rospy.logwarn("Falló la ruta en el nodo: %s", node)
                return False

        rospy.loginfo("Ruta completada.")
        return True

    # ==========================================================
    # MODOS DE OPERACIÓN
    # ==========================================================

    def go_to_target_from_current_position(self, target):
        target = self.normalize_target(target)

        if target not in self.nodes:
            rospy.logerr("Objetivo no reconocido: %s", target)
            rospy.loginfo("Objetivos disponibles: %s", list(self.nodes.keys()))
            return False

        start = self.get_nearest_node()

        if start is None:
            return False

        path = self.shortest_path(start, target)

        if path is None:
            return False

        return self.follow_path(path)

    def patrol_once(self):
        rospy.loginfo("Iniciando patrulla por roadmap una vez...")

        for target in self.patrol_route:
            ok = self.go_to_target_from_current_position(target)

            if not ok:
                rospy.logwarn("No se pudo llegar al punto de patrulla: %s", target)
                return False

        rospy.loginfo("Patrulla completada.")
        return True

    def patrol_loop(self):
        rospy.loginfo("Iniciando patrulla por roadmap en bucle...")

        while not rospy.is_shutdown():
            self.patrol_once()


def print_usage():
    print("Uso:")
    print("  rosrun garbage_truck_mission roadmap_navigator.py patrol")
    print("  rosrun garbage_truck_mission roadmap_navigator.py patrol_loop")
    print("  rosrun garbage_truck_mission roadmap_navigator.py go plastico")
    print("  rosrun garbage_truck_mission roadmap_navigator.py go organico")
    print("  rosrun garbage_truck_mission roadmap_navigator.py go vidre")
    print("  rosrun garbage_truck_mission roadmap_navigator.py go papel")
    print("")
    print("También puedes ir a un nodo concreto:")
    print("  rosrun garbage_truck_mission roadmap_navigator.py go patrulla_3")


def main():
    if len(sys.argv) < 2:
        print_usage()
        return

    navigator = RoadmapNavigator()

    command = sys.argv[1].lower()

    if command == "patrol":
        navigator.patrol_once()

    elif command == "patrol_loop":
        navigator.patrol_loop()

    elif command == "go":
        if len(sys.argv) < 3:
            print_usage()
            return

        target = sys.argv[2]
        navigator.go_to_target_from_current_position(target)

    else:
        rospy.logerr("Comando no reconocido: %s", command)
        print_usage()


if __name__ == "__main__":
    main()
