#!/usr/bin/env python3

import sys
import rospy
import actionlib

from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal


class ContainerNavigator:
    def __init__(self):
        rospy.init_node("go_to_container_node")

        self.client = actionlib.SimpleActionClient("move_base", MoveBaseAction)

        rospy.loginfo("Esperando a move_base...")
        self.client.wait_for_server()
        rospy.loginfo("move_base disponible.")

        # Waypoints reales guardados desde /amcl_pose.
        #
        # x, y = pose.pose.position.x / pose.pose.position.y
        # z, w = pose.pose.orientation.z / pose.pose.orientation.w
        #
        # IMPORTANTE:
        # Estos puntos NO son la posición física exacta del contenedor.
        # Son la pose donde debe colocarse el centro del Waffle para soltar basura,
        # mirando hacia cada contenedor.

        self.containers = {
            "vidre": {
                "x": 1.6500804193258245,
                "y": -1.3318271871261982,
                "z": -0.6850370271833154,
                "w": 0.7285082507342285,
            },

            "plastico": {
                "x":  0.11187991625510584,
                "y": -0.0005844281071906,
                "z": 0.6764015728199873,
                "w": 0.7365330354346962,
            },

            "organico": {
                "x": 0.8005334256400786,
                "y":  -0.20054028045120742,
                "z": 0.7763026348664682,
                "w": 0.6303603882695825,
            },

            "paper_carto": {
                "x": 1.3696525477104615,
                "y": 0.07230234959124221,
                "z":  0.6611935763660363,
                "w": 0.7502153388009942,
            },
        }

        # Alias para poder escribir nombres más cómodos desde terminal.
        self.aliases = {
            "contenedor_vidre": "vidre",
            "vidrio": "vidre",
            "glass": "vidre",

            "contenedor_plastico": "plastico",
            "plastic": "plastico",
            "plastico": "plastico",

            "contenedor_organico": "organico",
            "organic": "organico",
            "organico": "organico",

            "contenedor_paper_carto": "paper_carto",
            "contenedor_paper_cartó": "paper_carto",
            "paper": "paper_carto",
            "paper_carto": "paper_carto",
            "paper_cartó": "paper_carto",
            "carto": "paper_carto",
            "cartó": "paper_carto",
            "carton": "paper_carto",
            "cartón": "paper_carto",
            "papel": "paper_carto",
        }

    def normalize_name(self, name):
        name = name.strip().lower()
        return self.aliases.get(name, name)

    def go_to_container(self, name):
        name = self.normalize_name(name)

        if name not in self.containers:
            rospy.logerr("Contenedor no reconocido: %s", name)
            rospy.loginfo("Opciones disponibles:")
            rospy.loginfo("  vidre")
            rospy.loginfo("  plastico")
            rospy.loginfo("  organico")
            rospy.loginfo("  paper_carto")
            return False

        pose = self.containers[name]

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        goal.target_pose.pose.position.x = pose["x"]
        goal.target_pose.pose.position.y = pose["y"]
        goal.target_pose.pose.position.z = 0.0

        goal.target_pose.pose.orientation.x = 0.0
        goal.target_pose.pose.orientation.y = 0.0
        goal.target_pose.pose.orientation.z = pose["z"]
        goal.target_pose.pose.orientation.w = pose["w"]

        rospy.loginfo("Enviando robot al contenedor: %s", name)
        rospy.loginfo(
            "Pose objetivo -> x: %.3f, y: %.3f, z: %.3f, w: %.3f",
            pose["x"],
            pose["y"],
            pose["z"],
            pose["w"]
        )

        self.client.send_goal(goal)
        self.client.wait_for_result()

        state = self.client.get_state()

        # 3 = SUCCEEDED
        if state == 3:
            rospy.loginfo("Llegada correcta al contenedor: %s", name)
            return True

        rospy.logwarn(
            "No se ha llegado correctamente al contenedor %s. Estado move_base: %s",
            name,
            state
        )
        return False


def print_usage():
    print("Uso:")
    print("  rosrun garbage_truck_mission go_to_container.py vidre")
    print("  rosrun garbage_truck_mission go_to_container.py plastico")
    print("  rosrun garbage_truck_mission go_to_container.py organico")
    print("  rosrun garbage_truck_mission go_to_container.py paper_carto")
    print("")
    print("Alias aceptados:")
    print("  vidrio / glass -> vidre")
    print("  plastic -> plastico")
    print("  organic -> organico")
    print("  papel / paper / carton / carto -> paper_carto")


def main():
    if len(sys.argv) < 2:
        print_usage()
        return

    container_name = sys.argv[1]

    navigator = ContainerNavigator()
    navigator.go_to_container(container_name)


if __name__ == "__main__":
    main()
